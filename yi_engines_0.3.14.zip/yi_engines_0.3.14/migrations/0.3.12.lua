-- Reset recipes
for i, player in pairs(game.players) do
	player.force.reset_recipes()
end