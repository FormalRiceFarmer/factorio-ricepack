local M = MoConfig

if M.MegaTank then
	require("megatank")
end
