for i, recipe in pairs (data.raw.recipe) do
    
    recipe.enabled = true
    recipe.energy_required = nil
    recipe.ingredients = {}
    local fluidResult = false
    if recipe.results then
        for j, result in pairs (recipe.results) do
            if result.type == "fluid" then
                fluidResult = true
            else
            end
        end
    end
    if not fluidResult then
        recipe.category = nil
    end
end

