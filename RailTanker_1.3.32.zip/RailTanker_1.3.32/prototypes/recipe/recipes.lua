data:extend(
  {
    {
      type = "recipe",
      name = "rail-tanker",
      enabled = "false",
      ingredients =
      {
        {"iron-plate", 20},
        {"steel-plate", 10},
        {"iron-gear-wheel", 10}
      },
      result = "rail-tanker"
    },
  })
