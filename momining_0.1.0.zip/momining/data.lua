data.momining = true

MoConfig = MoConfig or {} --Create a empty table to store our config in

require("config")
require("prototypes.miningcontroltower")
require("base-edits")
