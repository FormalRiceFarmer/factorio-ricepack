game.reload_script()
