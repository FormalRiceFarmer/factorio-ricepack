data:extend({

	--[[
	{
		type = "technology",
		name = "y_f12defense",
		icon = "__Yuoki__/graphics/icons/yi_research.png",    
		effects = 
		{
			
			{ type = "unlock-recipe",   recipe = "y_wall22_hardic_recipe", },
			{ type = "unlock-recipe", recipe = "y-gun-turret-mk2-recipe", },
			
		},
		unit = {
			count = 25,
			ingredients = {{"science-pack-1", 1}},
			time = 15
		}
	},
	]]

})