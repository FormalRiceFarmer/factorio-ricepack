
if data.raw["item"]["stone"].stack_size < 51 then
	data.raw["item"]["stone"].stack_size=100
	data.raw["item"]["coal"].stack_size=100
	data.raw["item"]["raw-wood"].stack_size=100
	data.raw["item"]["iron-ore"].stack_size=100
	data.raw["item"]["copper-ore"].stack_size=100
end 
