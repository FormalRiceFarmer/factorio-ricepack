data:extend(
{
	{
		type = "straight-rail",
		name = "rail-bridge",
		icon = "__base__/graphics/icons/rail.png",
		flags = {"placeable-neutral", "player-creation", "building-direction-8-way"},
		minable = {mining_time = 1, result = "rail-bridge"},
		max_health = 100,
		corpse = "straight-rail-remnants",
		collision_box = {{-0.7, -0.8}, {0.7, 0.8}},
		selection_box = {{-0.7, -0.8}, {0.7, 0.8}},
		bending_type = "straight",
		rail_category = "regular",
		pictures = railpictures(),
		collision_mask = {"object-layer"},
	},
    {
    type = "rail-planner",
    name = "rail-bridge-planner",
    icon = "__base__/graphics/icons/rail.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "a[train-system]-a[rail-bridge]",
    place_result = "rail-bridge",
    stack_size = 100,
    straight_rail = "rail-bridge",
    curved_rail = "curved-rail"
  },
  {
    type = "item",
    name = "rail-bridge",
    icon = "__base__/graphics/icons/rail.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "a[train-system]-a[straight-rail]",
    place_result = "rail-bridge",
    stack_size = 50
  },
  {
    type = "recipe",
    name = "rail-bridge",
    enabled = "false",
    ingredients =
    {
      {"rail", 2}
    },
    result = "rail-bridge",
    result_count = 2
  },
  {
    type = "recipe",
    name = "rail-bridge-reverse",
    enabled = "false",
    ingredients =
    {
      {"rail-bridge", 2}
    },
    result = "rail",
    result_count = 2
  }
}
)