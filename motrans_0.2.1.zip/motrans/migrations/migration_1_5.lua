
for index, force in pairs(game.forces) do
	if force.technologies["railway"].researched then
		force.recipes["rail-bridge"].enabled = true
		force.recipes["rail-bridge-reverse"].enabled = true
	end
end