for index, force in pairs(game.forces) do
  force.resettechnologies()
  force.resetrecipes()
end

