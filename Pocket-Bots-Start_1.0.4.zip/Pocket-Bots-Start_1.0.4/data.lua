data:extend{
  { type = "technology", name = "bot-plan",
    icon = "__core__/graphics/factorio.png",
    effects =
    {
      {
        type = "ghost-time-to-live",
        modifier = 3600
      }
    },
    unit =
    {
      count = 1,
      ingredients =
      {
      },
      time = 1
    },
    order = "a-a-a",
  },
}