
require "defines"

local fastStart = false



if remote.interfaces.freeplay then
    script.on_event( defines.events.on_player_created, function( event )
        --[[ Thins to add ]]
        local items = {
                {"pistol", 1}
            ,   {"basic-bullet-magazine", 10}
            ,   {"stone-furnace", 1}
            ,   {"burner-mining-drill", 1}
            ,   {"deconstruction-planner", 1}
            ,   {"blueprint", 1}
            ,   {"basic-modular-armor", 1}
            ,   {"construction-robot", 10}
            ,   {"personal-roboport-equipment", 1}
            ,   {"solar-panel-equipment", 11}
            ,   {"battery-equipment", 5}
			,   {"iron-plate", 8}
            }
			
        local items2 =
	        {   {"basic-transport-belt", 100}
            ,   {"basic-transport-belt-to-ground", 4}
            ,   {"basic-splitter", 4}
            ,   {"basic-inserter", 20}
            ,   {"pipe", 20}
            ,   {"pipe-to-ground", 10}
            ,   {"submachine-gun", 1}
            ,   {"basic-mining-drill", 3}
            ,   {"stone-furnace", 4}
            ,   {"assembling-machine-1", 2}
            ,   {"boiler", 14}
            ,   {"small-electric-pole", 32}
            ,   {"steam-engine", 10}
            ,   {"offshore-pump", 1}
            }
        --[[ Tech to unlock ]]			
        local tech =
            {   "military"
	        ,   "automation"
	        ,   "logistics"
            }

        --[[ Recipes to unlock ]]			
        local recipes =
            {
            }

        --[[ The unlocking bits ]]
        local player = game.get_player( event.player_index )
        player.clear_items_inside()
        for i, v in pairs(items) do
            player.insert{name = v[1], count = v[2]}
        end
		player.force.technologies["bot-plan"].researched = true
		if fastStart == true then
			for i, v in pairs(items2) do
				player.insert{name = v[1], count = v[2]}
			end
			for i, v in pairs(tech) do
				player.force.technologies[v].researched = true
			end
			for i, v in pairs(recipes) do
				player.force.recipes[v].enabled = true
			end
		end
    end )
end
