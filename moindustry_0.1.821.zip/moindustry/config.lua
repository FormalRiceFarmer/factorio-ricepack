local M = MoConfig



-------------------------------------------
--------------Robot Mining-----------------
-------------------------------------------
--Listings of minable resources for mining bots.
M.DMO = {
	{
		OreName="copper-ore",
		ItemResult="copper-ore",
		Yield=1,
		MiniumCount=0,
		NormalCount=1
	},
	{
		OreName="iron-ore",
		ItemResult="iron-ore",
		Yield=1,
		MiniumCount=0,
		NormalCount=1
	},
	{
		OreName="coal",
		ItemResult="coal",
		Yield=1,
		MiniumCount=0,
		NormalCount=1
	},
	{
		OreName="stone",
		ItemResult="stone",
		Yield=1,
		MiniumCount=0,
		NormalCount=1
	}
}