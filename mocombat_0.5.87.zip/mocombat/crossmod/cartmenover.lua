--Cartmenoverhaul Mod Settings.

MoConfig.ModCompat = {}
local MC = MoConfig.ModCompat

MC.CombatBotsResearch = {"robotics","capsule-4"}