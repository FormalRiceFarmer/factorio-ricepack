data:extend({
  {
    type = "recipe",
    name = "module-inserter",
    energy_required = 1,
    ingredients = {
      { "advanced-circuit", 1 }
    },
    result = "module-inserter",
    enabled = "false"
  }
})
