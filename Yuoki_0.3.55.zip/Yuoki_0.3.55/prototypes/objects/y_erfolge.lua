data:extend(
{

	-- items
	{
		type = "item",
		name = "yi_obelisk_A3_5X",
		icon = "__Yuoki__/graphics/entity/lamps/yi_obelisk_3.5icon.png",
		flags = {"goes-to-quickbar"},
		group = "yuoki-energy",
		subgroup = "y_erfolge",
		place_result = "yi_obelisk_A3_5X",
		stack_size = 50, default_request_amount = 10, 
		order = "la",
	},
		
	-- recipe
	--[[
	{
		type = "recipe",
		name = "yi_obelisk_A3_5X_recipe",
		icon = "__Yuoki__/graphics/entity/lamps/yi_obelisk_3.5icon.png",
		enabled = true,
		ingredients = 
		{    	  	
			{"y-raw-fuelnium", 1},
			{"y_structure_element", 3},
			{"y-orange-stuff", 4},
		},
		results=
		{
			{type="item", name="yi_obelisk_A3_5X", amount=1, },      	  						
			{type="item", name="y_rwtechsign", amount=10, },      	  						
		},				
		main_product="yi_obelisk_A3_5X",
		group = "yuoki-energy",
		subgroup = "y_erfolge",				 
		order = "la",
	},
	]]
	{
		type = "lamp",
		name = "yi_obelisk_A3_5X",
		icon = "__Yuoki__/graphics/entity/lamps/yi_obelisk_3.5icon.png",
		flags = {"placeable-neutral", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "yi_obelisk_A3_5X"},
		max_health = 1000,
		corpse = "small-remnants",
		collision_box = {{-0.8, -0.8}, {0.8, 0.8}},
		selection_box = {{-1.0, -1.0}, {1.0, 1.0}},
		energy_source = {type = "electric", input_priority = "secondary", usage_priority = "secondary-input", emissions = -1.0, },
		
		energy_usage_per_tick = "25KW",
		light = {intensity = 0.8, size = 70,},
		--light = {intensity = 0.9, size = 70},
		picture_off =
		{
			filename = "__Yuoki__/graphics/entity/lamps/yi_obelisk_3.5off.png",
			priority = "high",
			width = 256,
			height = 256, scale = 0.5,			
			shift = {0.5, -0.75}
		},
		picture_on =
		{
			filename = "__Yuoki__/graphics/entity/lamps/yi_obelisk_3.5on.png",
			priority = "high",
			width = 256,
			height = 256, scale = 0.5,			
			shift = {0.5, -0.75}
		},
		circuit_wire_max_distance = 10,
	},

	
	-- the bug -1
	-- items
	{
		type = "item",
		name = "yi_bug1",
		icon = "__Yuoki__/graphics/entity/lamps/statue_bug1_icon.png",
		flags = {"goes-to-quickbar"},
		group = "yuoki-energy",
		subgroup = "y_erfolge",
		place_result = "yi_bug1",
		stack_size = 50, default_request_amount = 10, 
		order = "2a",
	},
		
	-- recipe
	{
		type = "recipe",
		name = "yi_bug1_recipe",
		icon = "__Yuoki__/graphics/entity/lamps/statue_bug1_icon.png",
		enabled = true,
		ingredients = 
		{    	  	
			{"y-raw-fuelnium", 1},
			{"y_structure_element", 3},
			{"y-orange-stuff", 4},
		},
		results=
		{
			{type="item", name="yi_bug1", amount=1, },      	  						
			{type="item", name="y_rwtechsign", amount=10, },      	  						
		},				
		main_product="yi_bug1",
		group = "yuoki-energy",
		subgroup = "y_erfolge",				 
		order = "2a",
	},
	
	{
		type = "lamp",
		name = "yi_bug1",
		icon = "__Yuoki__/graphics/entity/lamps/statue_bug1_icon.png",
		flags = {"placeable-neutral", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "yi_bug1"},
		max_health = 1000,
		corpse = "small-remnants",
		collision_box = {{-0.8, -0.8}, {0.8, 0.8}},
		selection_box = {{-1.0, -1.0}, {1.0, 1.0}},
		energy_source = {type = "electric", input_priority = "secondary", usage_priority = "secondary-input", emissions = 0.5, },
		
		energy_usage_per_tick = "25KW",
		light = {intensity = 0.35, size = 8, color = {r=0.8, g=0.0, b=0.0}},
		--light = {intensity = 0.9, size = 70},
		picture_off =
		{
			filename = "__Yuoki__/graphics/entity/lamps/statue_bug1_off.png",
			priority = "high",
			width = 256,
			height = 256, scale = 0.5,			
			shift = {0.5, -0.75}
		},
		picture_on =
		{
			filename = "__Yuoki__/graphics/entity/lamps/statue_bug1_on.png",
			priority = "high",
			width = 256,
			height = 256, scale = 0.5,			
			shift = {0.5, -0.75}
		},
		circuit_wire_max_distance = 10,
	},



	
})