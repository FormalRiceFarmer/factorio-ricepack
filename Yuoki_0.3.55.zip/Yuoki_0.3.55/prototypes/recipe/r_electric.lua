data:extend(
{	
	{
		type = "recipe",
		name = "y-conductive-wire-1-recipe",
		energy_required = 2.0,
		enabled = "true",
		ingredients = {{"y-orange-stuff", 1}, {"copper-plate", 1}, }, 
		result = "y-conductive-wire-1",
		result_count = 4,
		order="p-w-a",	
		subgroup = "y_parts_e",
	},	
	{
		type = "recipe",
		name = "y-conductive-coil-1-recipe",
		energy_required = 3.0,
		enabled = "true",
		ingredients = {{"y-orange-stuff", 3}, {"y-refined-yres2", 1}}, 
		result = "y-conductive-coil-1",
		result_count = 3,
		order="p-w-b",	
		subgroup = "y_parts_e",
	},			
	
	{
		type = "recipe",
		name = "y_dotzetron_recipe",
		--category = "yuoki-formpress-recipe",		
		--category = "crafting-with-fluid",		
		energy_required = 4.0,
		enabled = "true",
		ingredients = {{"y-refined-yres2", 1}, {"y-crush-yres1", 3},}, 		
		result = "y_dotzetron",
		result_count = 3,
		order="p-c-6",	
		subgroup = "y_parts_e",		
	},	
	
	{
		type = "recipe",
		name = "y_chip_plate_recipe",
		--category = "yuoki-formpress-recipe",		
		energy_required = 4.0,
		enabled = "true",
		ingredients = {{"y-refined-yres2", 1}, {"y-richdust", 3}, }, 
		result = "y_chip_plate",
		result_count = 1,
		order="p-c-0",	
		subgroup = "y_parts_e",		
	},	
	
	{
		type = "recipe",
		name = "y-chip1-recipe",
		energy_required = 1.0,
		enabled = "true",
		ingredients = {{"y_chip_plate", 1}, {"y-orange-stuff", 1}, }, 
		result = "y-chip-1",
		result_count = 1,
		order="p-c-a",	
		subgroup = "y_parts_e",
	},	
	{
		type = "recipe",
		name = "y-chip2-recipe",
		icon = "__Yuoki__/graphics/gfx/chip2-icon.png",
		energy_required = 1.5,
		enabled = "true",
		ingredients = {{"y_chip_plate", 1}, {"y_dotzetron", 1}, {"y-conductive-wire-1", 2},}, 
		results = { {type="item", name="y-chip-2", amount=1,}, {type="item", name="y_rwtechsign", amount=1,}, },			
		main_product="y-chip-2",
		order="p-c-b",	
		subgroup = "y_parts_e",
	},	

	{
		type = "recipe",
		name = "yi_magnetron_recipe",
		icon = "__Yuoki__/graphics/icons/magnetron.png",
		energy_required = 1.5,
		enabled = "true",
		ingredients = {{"y-pure-copper", 2}, {"y-heat-pipe", 1}, {"y-richdust", 3}, }, 
		results = { {type="item", name="yi_magnetron", amount=1,}, {type="item", name="y_rwtechsign", amount=1,}, },	
		main_product="yi_magnetron",		
		result_count = 1,
		order="p-c-b",	
		subgroup = "y_parts_e",
	},	

	
	-- new battery-concept from 215-0101
	-- basic-cell + combine cells
	
	-- basic cell empty
	{
		type = "recipe",
		name = "y-battery-singleuse1-recipe",		
		energy_required = 2.0,
		enabled = "true",
		ingredients = {{"y-crush-yres2", 3}, {"coal", 1}, {"iron-plate", 1} }, 
		result = "y-battery-single-use1",
		result_count = 3,
		order="p-b-a",	
	},	
	-- loaded cell
	{
		type = "recipe",
		name = "y-battery-singleuse2-recipe",		
		energy_required = 4.0,
		enabled = "true",		
		ingredients = {{"y-battery-single-use1", 1},}, 
		result = "y-battery-single-use2",
		result_count = 1,
		order="p-b-b",	
	},		
	-- block loaded cells
	{
		type = "recipe",
		name = "y-battery-single-use3-recipe",
		icon = "__Yuoki__/graphics/gfx/battery_3.png",
		energy_required = 4.0,
		enabled = "true",
		ingredients = {{"y-battery-single-use2", 2}, {"y-conductive-wire-1", 1 },}, 
		results = { {type="item", name="y-battery-single-use3", amount=1,}, {type="item", name="y_rwtechsign", amount=1,}, },
		main_product="y-battery-single-use3",
		order="p-b-c",	
		subgroup = "y-electric",
	},		
	
	--single-use-mod-batterys to standard-batterys
	{
		type = "recipe",
		name = "y-battery-rip1-recipe",				
		energy_required = 1.0,
		enabled = "true",
		ingredients = {{"y-battery-single-use1", 10},{"y_rwtechsign", 10},}, 
		result = "battery",
		result_count = 5,
	},	
	
	-- blocked capaciter
	{
		type = "recipe",
		name = "y_blocked_capa_recipe",
		icon = "__Yuoki__/graphics/gfx/scd-icon.png",
		energy_required = 3.0,
		enabled = "true",
		ingredients = {{"y-battery-single-use3", 4}, {"y-conductive-wire-1", 2 }, {"y-chip-1", 1 },}, 
		results = { {type="item", name="y_blocked_capa", amount=1,}, {type="item", name="y_rwtechsign", amount=1,},},
		order="p-b-d",	
		subgroup = "y-electric",
	},				
	{
		type = "recipe",
		name = "y-substation-m-recipe",
		icon = "__Yuoki__/graphics/icons/substation-icon.png",
		energy_required = 3.0,
		enabled = "true",
		ingredients = {{"substation", 1}, {"y-conductive-wire-1", 6}, {"y-chip-1", 1}, {"y-unicomp-a2", 2}, },		
		results = { {type="item", name="y-substation-m", amount=1,}, {type="item", name="y_rwtechsign", amount=1,}, },
		main_product="y-substation-m",
		order="e-e-a",	
		subgroup = "y-lamps",
	},	

	{
		type = "recipe",
		name = "y-substation-h-recipe",
		energy_required = 3.0,
		enabled = "true",
		ingredients = {{"y-substation-m", 1}, {"y-conductive-wire-1", 8}, {"y-chip-2", 4}, {"y_quantrinum_infused", 1}, {"y_rwtechsign", 3}, },
		result = "y-substation-h",
		result_count = 1,
		order="e-e-b",	
	},	

	
	-- Tier 1 - Accumulators
	--[[
	{
		type = "recipe",
		name = "y-accumulator-s-recipe",
		energy_required = 4.0, enabled = "true",
		ingredients = {{"y-battery-single-use3", 2}, {"y-pure-copper", 1}, {"electronic-circuit", 1}, {"iron-plate", 2},},
		result = "y-accumulator-s", result_count = 1,
		order="st1a",	
	},	
	]]
	{
		type = "recipe",
		name = "y-accumulator-m-recipe",
		energy_required = 6.0, enabled = "true",
		ingredients = {{"y_blocked_capa", 3}, {"y-pure-copper", 4}, {"y-chip-1", 1}, {"iron-plate", 2}, },
		result = "y-accumulator-m", result_count = 1,
		order="ac-1",	
		subgroup = "y-energy-2",
	},		
	-- Big Advanced Accum
	{
		type = "recipe",
		name = "y-accumulator-b-recipe",
		icon = "__Yuoki__/graphics/gfx/accu_b_icon.png",
		energy_required = 8.0, enabled = "true",
		ingredients = {{"y-accumulator-m", 2}, {"y-conductive-wire-1", 8}, {"y-chip-1", 4}, {"steel-plate", 10},},
		results = { {type="item", name="y-accumulator-b", amount=1,}, {type="item", name="y_rwtechsign", amount=1,},},		
		main_product="y-accumulator-b",
		--results = { {type="item", name="y-accumulator-b", amount=1,},},	
		order="ac-3",	
		subgroup = "y-energy-2",
	},		
	
	
	-- Tier 2 - Accumulators	
	-- Medium T2
	{
		type = "recipe",
		name = "y-accumulator-mt2-recipe",
		energy_required = 6.0, enabled = "true",
		ingredients = {{"y-accumulator-m", 1}, {"y-conductive-wire-1", 6}, {"y-chip-2", 2}, {"y-conductive-coil-1", 2}, {"y-crystal-cnd", 1},{"y_rwtechsign", 1},},
		result = "y-accumulator-m-t2", result_count = 1,
		order="ac-2",	
		subgroup = "y-energy-2",
	},		
	{
		type = "recipe",
		name = "y-accumulator-bt2-recipe",
		energy_required = 8.0, enabled = "true",
		ingredients = {{"y-accumulator-b", 1}, {"y-conductive-wire-1", 8}, {"y-chip-2", 2}, {"y-conductive-coil-1", 2}, {"y-crystal-cnd", 1},{"y_rwtechsign", 1},},
		result = "y-accumulator-b-t2", result_count = 1,
		order="ac-4",	
		subgroup = "y-energy-2",
	},		
	
	-- Tier 3 - Accumulators - AQE
	{
		type = "recipe",
		name = "y-accumulator-btx-recipe",
		category="yuoki-wonder-recipe";
		energy_required = 8.0, enabled = "true",
		ingredients = {{"y_structure_element", 10}, {"y-chip-2", 4}, {"y-raw-fuelnium", 10}, {"y-quantrinum", 2}, {"y-infused-uca2", 2}, {"y_rwtechsign", 3},},
		result = "y-accumulator-b-tx", result_count = 1,
		order="ac-5",	
		subgroup = "y-energy-2",
	},		
	-- Tier 4 - Accumulators - Crystal	
	{
		type = "recipe",
		name = "y-accumulator-crystal-m-recipe",
		category="yuoki-wonder-recipe";
		energy_required = 8.0, enabled = "true",
		ingredients = {{"y_wall22_hardic", 4},{"y_quantrinum_infused", 2}, {"y_crystal2_combined", 10}, {"y-conductive-coil-1", 40}, {"y_rwtechsign", 5},},
		result = "y-accumulator-crystal-m", result_count = 1,
		order="ac-6",	
		subgroup = "y-energy-2",
	},	

	-- Tier 1.5 - Accumulators
	{
		type = "recipe",
		name = "y-ups-flywheel-b-recipe",
		icon = "__Yuoki__/graphics/gfx/accflywheel_b_icon.png",
		energy_required = 12.0, enabled = "true",
		ingredients = {{"y-accumulator-m", 2}, {"y-conductive-coil-1", 4}, {"y-basic-t1-mf", 2}, {"y-chip-1", 1},},
		results = { {type="item", name="y-ups-flywheel-b", amount=1,}, {type="item", name="y_rwtechsign", amount=1,},},							
		main_product="y-ups-flywheel-b",
		order="ac-7",	
		subgroup = "y-energy-2",
	},	
	
	-- Compensator 2.5 MW
	{
		type = "recipe",
		name = "y_compensator_25_recipe",
		--category="yuoki-wonder-recipe";
		energy_required = 5.0, enabled = "true",
		ingredients = {{"y-substation-m", 1},{"y-conductive-wire-1", 4}, {"y-chip-2", 2},{"y_blocked_capa", 2}, {"y_rwtechsign", 2},},
		result = "y_compensator_25", result_count = 1,
		order="ac-8",	
		subgroup = "y-energy-2",
	},	
	
	

	
})