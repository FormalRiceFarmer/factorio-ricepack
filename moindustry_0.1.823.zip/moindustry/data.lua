data.moindustry = true

MoConfig = MoConfig or {} --Create a empty table to store our config in

require("config")
require("prototypes.robotlogistics")
require("prototypes.extrarobotresearch")
require("base-edits")
