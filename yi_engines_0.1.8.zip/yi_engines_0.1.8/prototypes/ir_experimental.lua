data:extend(
{  

	{ type = "recipe", name = "ye_fassembly1_recipe", ingredients = {{"y-basic-t1-mf",2},{"y-bluegear",6}, {"y-chip-1",4},}, result = "ye_fassembly1", enabled = "true", result_count = 1, order="engine", subgroup = "yie_machinery", },		
	{ type = "item", name = "ye_fassembly1", icon = "__yi_engines__/graphics/entity/fastassembly1_icon.png", flags = {"goes-to-quickbar"}, order = "a", place_result = "ye_fassembly1", stack_size = 20, subgroup = "yie_machinery", },

--[[
	{ type = "recipe", name = "ye_fassembly2_recipe", ingredients = {{"iron-plate",1},}, result = "ye_fassembly2", enabled = "true", result_count = 1, order="engine", subgroup = "yie_machinery", },		
	{ type = "item", name = "ye_fassembly2", icon = "__yi_engines__/graphics/entity/fastassembly1_icon.png", flags = {"goes-to-quickbar"}, order = "a", place_result = "ye_fassembly2", stack_size = 20, subgroup = "yie_machinery", },
]]
	
})	
	