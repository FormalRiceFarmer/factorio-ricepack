function RegisterOre(name,result,min,norm,yield)
	Ores[name]={result=result,min=(min or 0),norm=(norm or 1),yield = (yield or 1)}
end

RegisterOre("copper-ore","copper-ore")
RegisterOre("iron-ore","iron-ore")
RegisterOre("coal","coal")
RegisterOre("stone","stone")

ModInterface.RegisterOre = function(name,result)
	RegisterOre(name,result)
end
